﻿using ArmyEditor.Models;

namespace ArmyEditor.Logic
{
	public interface IArmyLogic
	{
		int AllCost { get; }
		double AVGPower { get; }
		double AVGSpeed { get; }

		void AddToArmy(Trooper trooper);
		void RemoveFromArmy(Trooper trooper);
		void SetupCollections(IList<Trooper> barrack, IList<Trooper> army);
		void EditTrooper(Trooper trooper);

	}
}