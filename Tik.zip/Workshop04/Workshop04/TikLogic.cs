﻿using CommunityToolkit.Mvvm.Messaging;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Threading;

namespace Workshop04
{
	public class TikLogic : ITikLogic
	{
		Random rnd=new Random();
		
		IList<Tik> tikok;
		IMessenger messenger;
		int gatheredEggs;
		public TikLogic(IMessenger messenger)
		{
			this.messenger = messenger;
			gatheredEggs = 0;
		}
		public void SetupCollection(IList<Tik> tikok)
		{
			this.tikok = tikok;
		}
		public void AddFood(Tik tik)
		{
			DispatcherTimer timer = new DispatcherTimer();
			timer.Interval = TimeSpan.FromSeconds(1);
			int remainingTime = rnd.Next(1, 6);
			timer.Tick += (_, _) =>
			{
				remainingTime--;
				if (remainingTime== 0)
				{
					timer.Stop();
					tik.Eggs = rnd.Next(1, 5);
				}

			};
			timer.Start();
			messenger.Send("Food added", "TikInfo");
		}
		public void GatherEggs(Tik tik)
		{
			gatheredEggs += tik.Eggs;
			tik.Eggs = 0;
			messenger.Send("Eggs gathered", "TikInfo");
		}
		public int GatheredEggs
		{ get { return gatheredEggs; } }
	}
}
