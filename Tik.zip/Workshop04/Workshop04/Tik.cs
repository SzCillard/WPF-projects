﻿using CommunityToolkit.Mvvm.ComponentModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Workshop04
{
	public class Tik : ObservableObject
	{
		string name;
		int eggs;
		public Tik(string name)
		{
			this.name = name;
			this.eggs = 0;
		}

		public string Name { get { return name; } set { name = value; } }
		public int Eggs {  get { return eggs; } set { SetProperty(ref eggs, value); } }
        

    }
}
