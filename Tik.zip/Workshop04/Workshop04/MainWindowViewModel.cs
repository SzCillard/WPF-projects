﻿using CommunityToolkit.Mvvm.ComponentModel;
using CommunityToolkit.Mvvm.DependencyInjection;
using CommunityToolkit.Mvvm.Input;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;

namespace Workshop04
{
	public class MainWindowViewModel : ObservableRecipient
	{
		ITikLogic logic;
		public ObservableCollection<Tik> tikok {  get; set; }
		public ICommand AddFood { get; set; }
		public ICommand GatherEggs { get; set; }
		Tik selectedTik;
		public Tik SelectedTik 
		{ 
			get { return selectedTik; } 
			set 
			{ 
				SetProperty(ref selectedTik, value);
				(AddFood as RelayCommand).NotifyCanExecuteChanged();
				(GatherEggs as RelayCommand).NotifyCanExecuteChanged();
			}
		}
		public static bool IsInDesignMode
		{
			get
			{
				var prop = DesignerProperties.IsInDesignModeProperty;
				return (bool)DependencyPropertyDescriptor.FromProperty(prop, typeof(FrameworkElement)).Metadata.DefaultValue;
			}
		}
		public MainWindowViewModel()
						: this(IsInDesignMode ? null : Ioc.Default.GetService<ITikLogic>())
		{

		}
        public MainWindowViewModel(ITikLogic logic)
        {
			this.logic = logic;
			tikok=[new Tik("Aranka"), new Tik("Kotkoda")];
			logic.SetupCollection(tikok);
			AddFood = new RelayCommand(
				() => logic.AddFood(SelectedTik),()=> SelectedTik != null
				);
			GatherEggs = new RelayCommand(
				() => logic.GatherEggs(SelectedTik), () => SelectedTik != null
				);
			Messenger.Register<MainWindowViewModel, string, string>(this, "TikInfo", (recipient, msg) =>
				{
					OnPropertyChanged("GatheredEggs");
				}
			);
		}
		public int GatheredEggs { get {  return logic.GatheredEggs; } }
	}
}
