﻿
namespace Workshop04
{
	public interface ITikLogic
	{
		int GatheredEggs { get; }

		void AddFood(Tik tik);
		void GatherEggs(Tik tik);
		void SetupCollection(IList<Tik> tikok);
	}
}