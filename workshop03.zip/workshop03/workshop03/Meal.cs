﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;

namespace workshop03
{
    public class Meal : INotifyPropertyChanged
    {
        string name;
        string type;
        int price;

        public Meal(string name, string type, int price)
        {
            this.Name = name;
            this.Type = type;
            this.Price = price;
        }

        public string Name { get => name; set { name = value; OnPropertyChanged(); } }
        public string Type { get => type; set { type = value; OnPropertyChanged(); } }
        public int Price { get => price; set { price = value; OnPropertyChanged(); } }

        public event PropertyChangedEventHandler? PropertyChanged;
        private void OnPropertyChanged([CallerMemberName] string propertyName = "")
        {
            PropertyChangedEventHandler handler = PropertyChanged;
            if (handler != null)
                handler(this, new PropertyChangedEventArgs(propertyName));
        }
    }
}
