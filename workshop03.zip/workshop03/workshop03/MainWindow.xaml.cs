﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace workshop03
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        ObservableCollection<Meal> allFoods;
        ObservableCollection<Meal> displayFoods;
        ObservableCollection<Meal> orderedFoods;
        int Sum;

        public MainWindow()
        {
            InitializeComponent();
            allFoods = new ObservableCollection<Meal>()
            {
                new Meal("Tavaszi zöldségleves", "Appetizer", 990),
                new Meal("Dreher", "Drink", 590),
                new Meal("Bécsi szelet", "MainCourse", 2190),
                new Meal("Rákóczi túrós", "Dessert", 790)
            };
            lbox_all.ItemsSource=allFoods;
             displayFoods= new ObservableCollection<Meal>();
             orderedFoods= new ObservableCollection<Meal>();
        }

    }
}
