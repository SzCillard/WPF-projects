﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Workshop02
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

       

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            Button wire = (sender as Button);
            StressWindow sw = new StressWindow(wire.Tag.ToString());
            if (sw.ShowDialog() == true)
            {
                wire.BorderBrush = Brushes.Green;
            }
            else
            {
                wire.BorderBrush = Brushes.LightPink;

            }
           // wire.IsEnabled = false;
        }
    }
}
