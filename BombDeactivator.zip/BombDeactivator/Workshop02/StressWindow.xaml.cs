﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Windows.Threading;

namespace Workshop02
{
    /// <summary>
    /// Interaction logic for StressWindow.xaml
    /// </summary>
    public partial class StressWindow : Window
    {
        DispatcherTimer timer;
        string wire = "";
        bool isButton;

        public StressWindow(string wire)
        {
            InitializeComponent();
            this.wire = wire;
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            isButton = false;
            this.lb_timer.Content = 10;
            timer=new DispatcherTimer();
            timer.Interval = TimeSpan.FromSeconds(1);
            timer.Tick += (_, _) =>
            {
                var remainingTime = (int)lb_timer.Content-1;

                this.lb_timer.Content =remainingTime;

                if (remainingTime == 0)
                {
                    timer.Stop();
                    this.DialogResult = false;
                }
                
            };
            timer.Start();
        }
        private void WireOptionClick(object sender, RoutedEventArgs e)
        {
           
            string wireColour = (sender as Button).Content.ToString();
            if (wire.ToLower()==wireColour.ToLower())
            {
                isButton = true;
                timer.Stop();
                this.DialogResult= true;
               
            }
            else {
                isButton = true;
                timer.Stop();
                this.DialogResult = false;
               
            }
           

        }

        private void Window_Closing(object sender, System.ComponentModel.CancelEventArgs e)
        {
            if ((int)lb_timer.Content!=0 && isButton==false)
            {
                MessageBoxResult result=MessageBox.Show("Biztos kilépsz?","Kilépés",MessageBoxButton.YesNo);
                if (result==MessageBoxResult.Yes)
                {
                    this.DialogResult = false;
                    lb_timer.Content = 0;
                    timer.Stop();
                        
                }
                else
                {
                    e.Cancel = true;
                }
            }
            
        }
    }
}
